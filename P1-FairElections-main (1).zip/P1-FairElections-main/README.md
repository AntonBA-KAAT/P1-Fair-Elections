# P1-FairElections
Vi er gruppe 10 på Aalborg Universitet Software bachelor uddannelsen, første semester, bestående af:
- Anton Bonde Andersen
- Christoffer Monterossi Munch
- Jacob Kjærsgaard Sand
- Mihnea Christian Spinu
- Mikkel Kibsgaard Dall
- Niklas Rainer Blok Larsen
- Phillip Moos Risager

Dette program har til formål at simulere USA's præsidentvalg under diverse valgsystemer.

OBS: kræver 16 GB RAM